import mongoose, { Schema, type InferSchemaType, type Model } from "mongoose";

const appSettingsSchema = new Schema(
  {
    _id: { type: String, default: "default" },
    apiKey: { type: String, required: true },
    rateLimitPerHour: { type: Number, default: 1000 },
    totalRequests: { type: Number, default: 0 },
  },
  { timestamps: true }
);

export type AppSettingsDocument = InferSchemaType<typeof appSettingsSchema> & {
  _id: string;
};

export const AppSettings: Model<AppSettingsDocument> =
  mongoose.models.AppSettings ??
  mongoose.model<AppSettingsDocument>("AppSettings", appSettingsSchema);
