import mongoose, { Schema, type InferSchemaType, type Model } from "mongoose";

const apiRequestLogSchema = new Schema(
  {
    endpoint: { type: String, required: true },
    method: { type: String, required: true },
    ipAddress: { type: String, default: null },
  },
  { timestamps: { createdAt: true, updatedAt: false } }
);

apiRequestLogSchema.index({ createdAt: 1 }, { expireAfterSeconds: 7 * 24 * 60 * 60 });

export type ApiRequestLogDocument = InferSchemaType<typeof apiRequestLogSchema> & {
  _id: mongoose.Types.ObjectId;
};

export const ApiRequestLog: Model<ApiRequestLogDocument> =
  mongoose.models.ApiRequestLog ??
  mongoose.model<ApiRequestLogDocument>("ApiRequestLog", apiRequestLogSchema);
