export async function register() {
  if (process.env.NEXT_RUNTIME === "nodejs") {
    const { scheduleChunkSessionCleanup } = await import("@/lib/chunk-upload");
    scheduleChunkSessionCleanup();
  }
}
