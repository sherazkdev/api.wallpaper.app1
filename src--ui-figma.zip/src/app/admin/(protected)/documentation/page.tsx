"use client";

import { useState } from "react";
import { Code, Shield, Zap } from "lucide-react";
import PageHeader from "@/components/admin/PageHeader";
import Card from "@/components/ui/Card";
import CopyButton from "@/components/ui/CopyButton";
import Badge from "@/components/ui/Badge";
import { APP } from "@/config/app";

const endpoints = [
  { method: "GET", path: "/api/v1/animations", desc: "List animations (ordered by display order)" },
  { method: "GET", path: "/api/v1/animations/:id", desc: "Get animation details" },
  { method: "POST", path: "/api/v1/animations", desc: "Create an animation" },
  { method: "PUT", path: "/api/v1/animations/:id", desc: "Update an animation" },
  { method: "DELETE", path: "/api/v1/animations/:id", desc: "Delete an animation" },
  { method: "POST", path: "/api/v1/animations/bulk-delete", desc: "Bulk delete animations" },
  { method: "POST", path: "/api/v1/animations/multi-upload", desc: "Multi video upload" },
  { method: "POST", path: "/api/v1/animations/zip-upload", desc: "ZIP upload (folder names become categories)" },
  { method: "GET", path: "/api/v1/categories", desc: "List animation categories" },
  { method: "POST", path: "/api/admin/animations/reorder", desc: "Reorder animations (admin)" },
];

const methodColors: Record<string, string> = {
  GET: "bg-emerald-100 text-emerald-700",
  POST: "bg-violet-100 text-violet-700",
  PUT: "bg-amber-100 text-amber-700",
  DELETE: "bg-red-100 text-red-700",
};

const codeTabs = ["cURL", "JavaScript", "Python"];

export default function DocumentationPage() {
  const [activeCodeTab, setActiveCodeTab] = useState("cURL");
  const baseUrl = typeof window !== "undefined" ? window.location.origin : "http://localhost:3000";

  const curlExample = `curl -X GET "${baseUrl}/api/v1/animations" \\
  -H "x-api-key: YOUR_API_KEY" \\
  -H "Accept: application/json" \\
  -G --data-urlencode "page=1" \\
  --data-urlencode "per_page=10"`;

  const jsExample = `const response = await fetch("${baseUrl}/api/v1/animations?page=1&per_page=10", {
  headers: {
    "x-api-key": "YOUR_API_KEY",
    "Accept": "application/json"
  }
});
const data = await response.json();`;

  const pythonExample = `import requests

response = requests.get(
    "${baseUrl}/api/v1/animations",
    headers={"x-api-key": "YOUR_API_KEY"},
    params={"page": 1, "per_page": 10}
)
data = response.json()`;

  const codeExamples: Record<string, string> = { cURL: curlExample, JavaScript: jsExample, Python: pythonExample };

  const jsonResponse = `{
  "success": true,
  "data": {
    "animations": [
      {
        "id": "clx123abc",
        "name": "animation1",
        "order": 1,
        "url": "${baseUrl}/uploads/animations/example.mp4",
        "fileName": "example.mp4",
        "fileSize": 15728640,
        "format": "MP4",
        "mimeType": "video/mp4",
        "width": 1920,
        "height": 1080,
        "duration": 15.5,
        "thumbnailUrl": "${baseUrl}/uploads/thumbnails/animations/example.jpg",
        "status": "Published",
        "createdAt": "2026-06-18T10:30:00.000Z"
      }
    ],
    "pagination": {
      "page": 1,
      "perPage": 10,
      "total": 1,
      "totalPages": 1
    }
  }
}`;

  return (
    <div>
      <PageHeader
        title="API Documentation"
        subtitle={`Complete reference for integrating with the ${APP.name}.`}
        breadcrumbs={["Dashboard", "Documentation"]}
      />

      <div className="grid md:grid-cols-3 gap-4 mb-8">
        {[
          { icon: Code, title: "Simple & Easy", desc: "RESTful endpoints with ordered animation responses" },
          { icon: Shield, title: "Secure", desc: "All requests require a valid x-api-key header" },
          { icon: Zap, title: "Fast", desc: "Optimized delivery with pagination support" },
        ].map(({ icon: Icon, title, desc }) => (
          <Card key={title} className="flex items-start gap-4">
            <div className="w-10 h-10 bg-violet-50 rounded-xl flex items-center justify-center flex-shrink-0">
              <Icon className="w-5 h-5 text-violet-600" />
            </div>
            <div>
              <h3 className="font-semibold text-slate-900">{title}</h3>
              <p className="text-sm text-slate-500 mt-1">{desc}</p>
            </div>
          </Card>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <div className="space-y-6">
          <Card>
            <h3 className="font-semibold text-slate-900 mb-3">Base URL</h3>
            <div className="flex items-center gap-2 bg-slate-50 rounded-xl px-4 py-3 border border-slate-200/80">
              <code className="text-sm font-mono text-slate-800 flex-1">{baseUrl}/api/v1</code>
              <CopyButton text={`${baseUrl}/api/v1`} />
            </div>
          </Card>

          <Card>
            <h3 className="font-semibold text-slate-900 mb-3">Authentication</h3>
            <p className="text-sm text-slate-600 mb-3">Include your API key in every request. Missing or invalid keys return 401.</p>
            <div className="flex items-center gap-2 bg-slate-50 rounded-xl px-4 py-3 border border-slate-200/80">
              <code className="text-sm font-mono text-slate-800 flex-1">x-api-key: YOUR_API_KEY</code>
              <CopyButton text="x-api-key: YOUR_API_KEY" />
            </div>
          </Card>

          <Card>
            <h3 className="font-semibold text-slate-900 mb-4">Available Endpoints</h3>
            <div className="space-y-2">
              {endpoints.map(({ method, path, desc }) => (
                <div key={`${method}-${path}`} className="flex items-center gap-2 py-1.5">
                  <span className={`px-1.5 py-0.5 rounded text-xs font-bold font-mono ${methodColors[method]}`}>{method}</span>
                  <code className="text-xs font-mono text-slate-700">{path}</code>
                  <span className="text-xs text-slate-400 ml-auto hidden sm:block">{desc}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>

        <div className="space-y-6">
          <Card padding={false} className="overflow-hidden">
            <div className="flex items-center justify-between p-4 border-b border-slate-700 bg-slate-900">
              <span className="text-sm font-medium text-slate-300">Example Request</span>
              <div className="flex gap-1">
                {codeTabs.map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveCodeTab(tab)}
                    className={`px-3 py-1 rounded-lg text-xs font-medium transition-colors ${
                      activeCodeTab === tab ? "bg-violet-600 text-white" : "text-slate-400 hover:text-white"
                    }`}
                  >
                    {tab}
                  </button>
                ))}
              </div>
            </div>
            <pre className="p-4 text-xs font-mono text-slate-300 bg-slate-900 overflow-x-auto leading-relaxed min-h-[200px]">
              {codeExamples[activeCodeTab]}
            </pre>
          </Card>

          <Card padding={false} className="overflow-hidden">
            <div className="flex items-center justify-between p-4 border-b border-slate-200/80">
              <span className="text-sm font-medium text-slate-700">Example Response</span>
              <div className="flex items-center gap-2">
                <Badge variant="info">JSON</Badge>
                <CopyButton text={jsonResponse} />
              </div>
            </div>
            <pre className="p-4 text-xs font-mono text-slate-700 bg-slate-50 overflow-x-auto leading-relaxed max-h-[400px]">
              {jsonResponse}
            </pre>
          </Card>
        </div>
      </div>

      <div className="mt-6 p-4 bg-gradient-to-r from-violet-600 to-indigo-600 rounded-2xl text-white flex items-center gap-3 shadow-premium">
        <Shield className="w-5 h-5 flex-shrink-0" />
        <p className="text-sm">
          Need integration help? Contact{" "}
          <a href={`mailto:${APP.supportEmail}`} className="underline font-medium">{APP.supportEmail}</a>
        </p>
      </div>
    </div>
  );
}
