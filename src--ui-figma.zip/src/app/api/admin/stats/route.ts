export const runtime = "nodejs";

import { requireAdmin, apiSuccess } from "@/lib/api-utils";
import { ensureAppSettings } from "@/lib/api-key";
import { getAnimationCounts, getAnimationStorageUsed } from "@/lib/animation-service";
import { connectMongoDB } from "@/lib/mongodb";
import { AppSettings } from "@/models/AppSettings";
import { Category } from "@/models/Category";

export async function GET() {
  const authError = await requireAdmin();
  if (authError) return authError;

  await ensureAppSettings();
  await connectMongoDB();

  const [counts, storageUsed, settings, categoryCount] = await Promise.all([
    getAnimationCounts(),
    getAnimationStorageUsed(),
    AppSettings.findById("default").lean(),
    Category.countDocuments(),
  ]);

  return apiSuccess({
    totalAnimations: counts.total,
    publishedAnimations: counts.published,
    draftAnimations: counts.draft,
    totalCategories: categoryCount,
    storageUsed,
    apiStatus: "Active",
    totalApiRequests: settings?.totalRequests || 0,
  });
}
