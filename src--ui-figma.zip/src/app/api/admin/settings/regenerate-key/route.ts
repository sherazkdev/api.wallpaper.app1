export const runtime = "nodejs";

import { requireAdmin, apiSuccess } from "@/lib/api-utils";
import { generateApiKey } from "@/lib/api-key";
import { connectMongoDB } from "@/lib/mongodb";
import { AppSettings } from "@/models/AppSettings";

export async function POST() {
  const authError = await requireAdmin();
  if (authError) return authError;

  await connectMongoDB();
  const newKey = generateApiKey();
  await AppSettings.findOneAndUpdate(
    { _id: "default" },
    {
      $set: { apiKey: newKey },
      $setOnInsert: { totalRequests: 0, rateLimitPerHour: 1000 },
    },
    { upsert: true }
  );

  return apiSuccess({ apiKey: newKey });
}
