export const runtime = "nodejs";

import { requireAdmin, apiSuccess } from "@/lib/api-utils";
import { ensureAppSettings, getRateLimitInfo } from "@/lib/api-key";
import { connectMongoDB } from "@/lib/mongodb";
import { AppSettings } from "@/models/AppSettings";

export async function GET() {
  const authError = await requireAdmin();
  if (authError) return authError;

  await ensureAppSettings();
  await connectMongoDB();
  const settings = await AppSettings.findById("default").lean();
  const rateInfo = await getRateLimitInfo();

  return apiSuccess({
    apiStatus: "Active" as const,
    apiKey: settings?.apiKey || "",
    rateLimitPerHour: settings?.rateLimitPerHour || 1000,
    totalRequests: settings?.totalRequests || 0,
    rateLimitRemaining: rateInfo.remaining,
    rateLimitResetMinutes: rateInfo.resetMinutes,
  });
}
