import {
  LayoutDashboard,
  Clapperboard,
  CloudUpload,
  FolderArchive,
  Settings,
  BookOpen,
  type LucideIcon,
} from "lucide-react";

export interface AppTheme {
  activeNav: string;
  brandIcon: string;
  brandGradient: string;
  heroGradient: string;
  uploadZoneDrag: string;
  uploadZoneBorder: string;
  uploadZoneHover: string;
  uploadIconBg: string;
  uploadIcon: string;
  tipBg: string;
  tipText: string;
  link: string;
  linkHover: string;
  focusRing: string;
  checkbox: string;
  storageBar: string;
  accent: string;
  accentHover: string;
  accentLight: string;
}

export const APP = {
  name: "Animation API",
  tagline: "Premium animation content API for modern applications",
  singular: "Animation",
  plural: "Animations",
  description: "Manage and deliver high-quality animation videos through a secure REST API.",
  adminBasePath: "/admin/animations",
  apiBasePath: "/api/v1/animations",
  uploadSubdir: "animations",
  supportEmail: "support@animationapi.com",
  fileNamePattern: /^animation\d+\.mp4$/i,
} as const;

export const THEME: AppTheme = {
  activeNav: "bg-violet-50 text-violet-700",
  brandIcon: "bg-gradient-to-br from-violet-600 to-indigo-600",
  brandGradient: "bg-gradient-to-br from-violet-600 to-indigo-600",
  heroGradient: "bg-gradient-to-br from-violet-50 via-white to-indigo-50/40",
  uploadZoneDrag: "border-violet-400 bg-violet-50/80",
  uploadZoneBorder: "border-violet-200/80",
  uploadZoneHover: "hover:border-violet-300 hover:bg-violet-50/30",
  uploadIconBg: "bg-violet-100",
  uploadIcon: "text-violet-600",
  tipBg: "bg-violet-50",
  tipText: "text-violet-800",
  link: "text-violet-600",
  linkHover: "hover:text-violet-800",
  focusRing: "focus:ring-violet-500/40 focus:border-violet-400",
  checkbox: "text-violet-600 accent-violet-600",
  storageBar: "bg-gradient-to-r from-violet-500 to-indigo-500",
  accent: "bg-violet-600",
  accentHover: "hover:bg-violet-700",
  accentLight: "bg-violet-50",
};

export const SIDEBAR_NAV: Array<{
  href: string;
  label: string;
  icon: LucideIcon;
}> = [
  { href: "/admin/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/admin/animations", label: "Animations", icon: Clapperboard },
  { href: "/admin/animations/add", label: "Upload Animation", icon: CloudUpload },
  { href: "/admin/animations/zip-upload", label: "ZIP Upload", icon: FolderArchive },
  { href: "/admin/api-settings", label: "API Settings", icon: Settings },
  { href: "/admin/documentation", label: "Documentation", icon: BookOpen },
];
