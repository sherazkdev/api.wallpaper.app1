import { connectMongoDB } from "./mongodb";
import { AppSettings } from "@/models/AppSettings";
import { ApiRequestLog } from "@/models/ApiRequestLog";

export async function getApiKey(): Promise<string> {
  await connectMongoDB();
  const settings = await AppSettings.findById("default").lean();
  if (settings?.apiKey) return settings.apiKey;
  return process.env.API_SECRET_KEY || "";
}

export async function ensureAppSettings() {
  await connectMongoDB();
  const existing = await AppSettings.findById("default").lean();
  if (!existing) {
    const apiKey = process.env.API_SECRET_KEY || generateApiKey();
    await AppSettings.create({
      _id: "default",
      apiKey,
      totalRequests: 0,
      rateLimitPerHour: 1000,
    });
  }
}

export function generateApiKey(): string {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  let key = "wk_live_";
  for (let i = 0; i < 32; i++) {
    key += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return key;
}

export async function validateApiKey(providedKey: string | null): Promise<boolean> {
  if (!providedKey) return false;
  const validKey = await getApiKey();
  return providedKey === validKey;
}

export async function incrementApiRequests(endpoint: string, method: string, ip?: string) {
  await connectMongoDB();
  await AppSettings.updateOne({ _id: "default" }, { $inc: { totalRequests: 1 } });
  await ApiRequestLog.create({
    endpoint,
    method,
    ipAddress: ip || null,
  });
}

export async function getRateLimitInfo() {
  await connectMongoDB();
  const settings = await AppSettings.findById("default").lean();
  const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);
  const recentRequests = await ApiRequestLog.countDocuments({
    createdAt: { $gte: oneHourAgo },
  });
  const limit = settings?.rateLimitPerHour || 1000;
  const oldestInWindow = await ApiRequestLog.findOne({ createdAt: { $gte: oneHourAgo } })
    .sort({ createdAt: 1 })
    .select("createdAt")
    .lean();
  let resetMinutes = 60;
  if (oldestInWindow?.createdAt) {
    const resetTime = new Date(oldestInWindow.createdAt.getTime() + 60 * 60 * 1000);
    resetMinutes = Math.max(1, Math.ceil((resetTime.getTime() - Date.now()) / 60000));
  }
  return {
    limit,
    used: recentRequests,
    remaining: Math.max(0, limit - recentRequests),
    resetMinutes,
  };
}

export async function checkRateLimit(): Promise<boolean> {
  const info = await getRateLimitInfo();
  return info.used < info.limit;
}
